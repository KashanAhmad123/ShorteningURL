package com.rest.springb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbooTapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
